#include<stdio.h>    // Mobina Teromideh   40223021
int main()
{
    int n;


    printf("Enter a positive integer:");
    scanf("%d",&n);
    char a[n];
    scanf("%s",a);//user puts the string
    
    
    for(int i=0;i<n-1;i++)
    {
        if(a[i]==a[i+1])//repeated character
        {
                
        for(int j=i;j<n-1;j++)
        {
            a[j]=a[j+2];//example: ggh -->output:h   so a[j]=a[j+2]
            a[j+1]=a[j+3];
           
        }
        n=n-2;//array is going to delete 2 numbers of n(repeated ones)
        i=-1;//we want to start i from 0 so --> i=-1  +1 -->i=0
        
        
        
        printf("%s\n",a);
        }
    }  

return 0;
}
